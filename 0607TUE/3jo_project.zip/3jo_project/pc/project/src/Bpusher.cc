#include <functional>
#include <gazebo/gazebo.hh>
#include <gazebo/physics/physics.hh>
#include <gazebo/common/common.hh>
#include <ignition/math/Vector3.hh>
#include <thread>
#include "ros/ros.h"
#include "ros/callback_queue.h"
#include "ros/subscribe_options.h"
#include "std_msgs/Float32.h"
#include <gazebo/transport/transport.hh>
#include <gazebo/msgs/msgs.hh>

namespace gazebo
{
	class pusher : public ModelPlugin
	{
		public: void Load(physics::ModelPtr _model, sdf::ElementPtr )
			{
				this->model = _model;
				this->updateConnection = event::Events::ConnectWorldUpdateBegin(std::bind(&pusher::OnUpdate, this));
				std::string pusher_topic = "/black_pusher";

				if (!ros::isInitialized())
				{
					int argc = 0;
					char **argv = NULL;
					ros::init(argc, argv, "shelf_rosnode", ros::init_options::NoSigintHandler);
				}

				this->rosNode.reset(new ros::NodeHandle("shelf_rosnode"));
				ros::SubscribeOptions so = ros::SubscribeOptions::create<std_msgs::Float32>(pusher_topic, 1, boost::bind(&pusher::OnRosMsg, this, _1), ros::VoidPtr(), &this->rosQueue);
				this->rosSub = this->rosNode->subscribe(so);
				this->rosQueueThread = std::thread(std::bind(&pusher::QueueThread, this));
			}

		public: void OnUpdate()
			{
				double speed = this->vel;
				double speed_y = speed*this->direction;
				this->model->SetLinearVel(ignition::math::Vector3d(0,speed_y,0));
			}

		public: void SetVelocity(const double &_vel)
			{
				this->vel = _vel;
			}

		public: void OnRosMsg(const std_msgs::Float32ConstPtr &_msg)
			{
				this->SetVelocity(_msg->data);
			}

		private: void QueueThread()
			{
				static const double timeout = 0.01;
				while (this->rosNode->ok())
				{
					this->rosQueue.callAvailable(ros::WallDuration(timeout));
				}
			}

		private: physics::ModelPtr model;
		private: event::ConnectionPtr updateConnection;
		int direction = 1;
		double vel = 0.0;
		private: std::unique_ptr<ros::NodeHandle> rosNode;
		private: ros::Subscriber rosSub;
		private: ros::CallbackQueue rosQueue;
		private: std::thread rosQueueThread;
			
	};
	GZ_REGISTER_MODEL_PLUGIN(pusher)
}
