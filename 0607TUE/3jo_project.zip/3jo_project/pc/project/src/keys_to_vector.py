#!/usr/bin/env python

import rospy
from std_msgs.msg import String
from geometry_msgs.msg import Twist

key_mapping = {     'w':[150,0,150,0],
        'a':[150,0,0,150], 's':[0,0,0,0], 'd':[0,150,150,0],
                    'x':[0,150,0,150] }

def keys_cb(msg, Twist_pub):
    if len(msg.data) == 0 or not key_mapping.has_key(msg.data[0]):
        return #unknown key

    vels = key_mapping[msg.data[0]]
    
    t = Twist()
    t.linear.x = vels[0]
    t.linear.y = vels[1]
    t.angular.x = vels[2]
    t.angular.y = vels[3]
    vector_pub.publish(t)

if __name__=='__main__':
    rospy.init_node("keys_to_vector")
    vector_pub = rospy.Publisher('motor', Twist, queue_size=1)
    rospy.Subscriber('keys', String, keys_cb, vector_pub)
    rospy.spin()
