#include <ros.h>
#include <ros/time.h>
#include <tf/tf.h>
#include <tf/transform_broadcaster.h>
#include <geometry_msgs/Twist.h>
#include <geometry_msgs/TransformStamped.h>

int motorA1 = 5;
int motorA2 = 6;
int motorB1 = 9;
int motorB2 = 10;
float val1 = 0;
float val2 = 0;
float val3 = 0;
float val4 = 0;

char base_link[] = "/base_link";
char odom[] = "/odom";

ros::NodeHandle nh;
tf::TransformBroadcaster broadcaster;
geometry_msgs::TransformStamped t;

double x = 0.0;
double y = 0.0;
double theta = 0.0;

volatile float LWD = 0.0;
volatile float RWD = 0.0;
volatile float CD = 0.0;
float distance_per_sec = 0.45;
float distance_travelled = 0.0;
float len = 0.135;

double old_time = nh.now().toSec();

void serialEvent()
{
  double current_time = nh.now().toSec();
  double time_diff = current_time - old_time;
  distance_travelled = time_diff*distance_per_sec;
  old_time = current_time;
  
  if(!(val1 == 0))
  {
    LWD = LWD + distance_travelled;
  }
  else if(!(val2 == 0))
  {
    LWD = LWD - distance_travelled;
  }
  if(!(val3 == 0))
  {
    RWD = RWD + distance_travelled;
  }
  else if(!(val4 == 0))
  {
    RWD = RWD - distance_travelled;
  }

  CD = (LWD+RWD)/2;

  x = x+(CD*(cos(theta)));
  y = y+(CD*(sin(theta)));
  theta = theta+((LWD+RWD)/len);
}

void messageCB(const geometry_msgs::Twist &msg)
{
  val1 = msg.linear.x;
  val2 = msg.linear.y;
  val3 = msg.angular.x;
  val4 = msg.angular.y;
}

ros::Subscriber<geometry_msgs::Twist> sub("motor", &messageCB);

void setup() {
  nh.initNode();
  nh.subscribe(sub);
  broadcaster.init(nh);
  pinMode(motorA1, OUTPUT);
  pinMode(motorA2, OUTPUT);
  pinMode(motorB1, OUTPUT);
  pinMode(motorB2, OUTPUT);
}

void loop() {
  analogWrite(motorA1, val1);
  analogWrite(motorA2, val2);
  analogWrite(motorB1, val3);
  analogWrite(motorB2, val4);

  t.header.frame_id = odom;
  t.child_frame_id = base_link;

  t.transform.translation.x = x;
  t.transform.translation.y = y;

  t.transform.rotation = tf::createQuaternionFromYaw(theta);
  t.header.stamp = nh.now();

  broadcaster.sendTransform(t);
  
  nh.spinOnce();
  delay(10);
}
