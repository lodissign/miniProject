#include <function>
#include <gazebo/gazebo.hh>
#include <gazebo/physics/physics.hh>
#include <gazebo/common/common.hh>
#include <ignition/math/Vector3.hh>
#include <thread>
#include <ros/ros.h>
#include <ros/callback_queue.h>
#include <ros/subscribe_options.h>
#include <std_msgs/Float32.h>
#include <gazebo/transport/transport.hh>
#include <gazebo/msgs/msgs.hh>

namespace gazebo
{
	class ModelQuake : public ModelPlugin
	{
		public: void Load(physics::ModelPtr _parent, sdf::ElementPtr )
			{
				this->model = _parent;
				this->updateConnection = event::Events::ConnectWorldUpdateBegin(std::bind(&ModelQuake
			}
	};
}
