#include <ros/ros.h>
#include <tf/transform_broadcaster.h>
#include <nav_msgs/Odometry.h>
#include <geometry_msgs/Twist.h>
#include <geometry_msgs/TransformStamped.h>
  
void odomCB(const geometry_msgs::Twist::ConstPtr &msg);

double x = 0.0;
double y = 0.0;
double theta = 0.0;

volatile float LWD = 0.0;
volatile float RWD = 0.0;
volatile float CD = 0.0;
float distance_per_sec = 0.45;
float distance_travelled = 0.0;
float len = 0.135;

ros::Time current_time, old_time;
  

int main(int argc, char** argv){
  
  ros::init(argc, argv, "odometryyyy");
  ros::NodeHandle nh;
  tf::TransformBroadcaster odom_broadcaster;
  geometry_msgs::TransformStamped odom_transform;
  ros::Subscriber sub = nh.subscribe<geometry_msgs::Twist>("motor", 100, odomCB);

  ros::Rate r(1.0);

  while(nh.ok()){

    ros::spinOnce();               // check for incoming messages

    geometry_msgs::Quaternion odom_quat = tf::createQuaternionMsgFromYaw(theta);

    odom_transform.header.frame_id = "odom";
    odom_transform.child_frame_id = "base_footprint";

    odom_transform.transform.translation.x = x;
    odom_transform.transform.translation.y = y;
    odom_transform.transform.translation.z = 0.0;
    odom_transform.transform.rotation = odom_quat;

    odom_broadcaster.sendTransform(odom_transform);

    r.sleep();
    ros::spin();
  }
}


  void odomCB(const geometry_msgs::Twist::ConstPtr &msg)
{
  old_time = ros::Time::now();
  current_time = ros::Time::now();
  double time_diff = (current_time - old_time).toSec();
  distance_travelled = time_diff*distance_per_sec;
  old_time = current_time;

  if(!(msg->linear.x == 0))
  {
    LWD = LWD + distance_travelled;
  }
  else if(!(msg->linear.y == 0))
  {
    LWD = LWD - distance_travelled;
  }
  if(!(msg->angular.x == 0))
  {
    RWD = RWD + distance_travelled;
  }
  else if(!(msg->angular.y == 0))
  {
    RWD = RWD - distance_travelled;
  }

  CD = (LWD+RWD)/2;

  x = x+(CD*(cos(theta)));
  y = y+(CD*(sin(theta)));
  theta = theta+((LWD+RWD)/len);
}

