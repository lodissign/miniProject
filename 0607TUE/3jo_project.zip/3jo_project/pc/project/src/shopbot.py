#!/usr/bin/env python

import rospy
import actionlib
from geometry_msgs.msg import Pose
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal
from std_msgs.msg import Float32
import time


p1 = Pose()
p1.position.x = 4.18
p1.position.y = 1.36
p1.orientation.z = -1.1708
p1.orientation.w = 1


p2 = Pose()
p2.position.x = 2.8
p2.position.y = 4.0
p2.orientation.z = 0
p2.orientation.w = 1.0


p3 = Pose()
p3.position.x = 4.18
p3.position.y = 4.0
p3.orientation.z = 0
p3.orientation.w = 1.0


pub = rospy.Publisher('white_pusher', Float32, queue_size=1)
BLACK = Float32()
STOP = Float32()
BLACK.data = 2.1
STOP.data = 0.0


def goal_pose(pose):
    goal_pose = MoveBaseGoal()
    goal_pose.target_pose.header.frame_id = "map"
    goal_pose.target_pose.pose = pose
    return goal_pose

if __name__=='__main__':
    rospy.init_node('pat')

    client = actionlib.SimpleActionClient('move_base', MoveBaseAction)
    client.wait_for_server()

    goal = goal_pose(p1)
    client.send_goal(goal)
    client.wait_for_result()

    pub.publish(BLACK)
    time.sleep(2)
    pub.publish(STOP)
    time.sleep(2)
    
    goal = goal_pose(p3)
    client.send_goal(goal)
    client.wait_for_result()

    goal = goal_pose(p2)
    client.send_goal(goal)
    client.wait_for_result()
